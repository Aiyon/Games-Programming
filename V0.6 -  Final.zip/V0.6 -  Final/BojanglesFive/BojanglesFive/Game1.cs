﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Roguelike
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Game
    {

        KeyboardState oldState;

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        private Texture2D background;
        private Texture2D wall;
        private Texture2D grate;
        private Texture2D gameOverScreen;
        private Texture2D enemy1;
        private Texture2D hpBar;
        private Texture2D fog;
        private SpriteFont uiText;
        private SpriteFont GOText;

        //private Brain brain;

        private int tileSize;

        EnemyBase[] enemyList = new EnemyBase[30];

        private int[,] Tiles;
        private int[,] FoW;
        int pDist;

        int score;

        private bool gameOver;
        private bool fMode;

        private Player player;

        private MapGenV2 level1;

        public Game1()
            : base()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = 1200;
            graphics.PreferredBackBufferHeight = 750; //960
            graphics.ApplyChanges();

            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            Tiles = new int[80, 48];
            FoW = new int[80, 48];
            pDist = 5;
            tileSize = graphics.PreferredBackBufferWidth / 80;
            score = 0;
            fMode = true;

            //brain = new Brain();

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            background = Content.Load<Texture2D>("stars"); // change these names to the names of your images
            wall = Content.Load<Texture2D>("wall");
            grate = Content.Load<Texture2D>("grate");
            gameOverScreen = Content.Load<Texture2D>("GameOver");
            enemy1 = Content.Load<Texture2D>("RedEnemy");
            hpBar = Content.Load<Texture2D>("healthblob");
            fog = Content.Load<Texture2D>("FoW grey");
            uiText = Content.Load<SpriteFont>("font");
            GOText = Content.Load<SpriteFont>("bigfont");

            level1 = new MapGenV2();

            Tiles = level1.map();

            enemyList = level1.getEnemies();

            Vector2 spawn = level1.getSpawn();

            player = new Player((int)spawn.X * 10, (int)spawn.Y * 10);
            player.setExit(level1.getExit());

            clearFoW();

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here
            updateInput();
            player.Update(gameTime);

            base.Update(gameTime);

            if (player.isCleared())
            {
                Tiles = level1.map();
                player.newLevel();
                player.jumpRegardless(level1.getSpawn());
                player.setExit(level1.getExit());
                enemyList = level1.getEnemies();
                FoW = new int[80, 48];
                score += 100;
            }

            if (!player.isMove)
            {
                for (int i = 0; i < enemyList.Length; i++)
                {
                    if (enemyList[i] != null)
                    {
                        if (player.TargetPosition / 10 == enemyList[i].GridPosition)
                        {
                            if (enemyList[i].hit(player.Dmg) <= 0)
                            {
                                score += (enemyList[i].SV);
                                enemyList[i] = enemyDeath(enemyList[i]);
                                continue;
                            }
                        }


                        //get next tile from brain.
                        //brain.Build(Tiles, enemyList[i], player);

                        int numAtks = enemyList[i].doMonsterTurn(player, Tiles);
                        
                        if (numAtks != 0)
                        {
                            if (player.hit(enemyList[i].Atk * numAtks) <= 0)
                            {
                                gameOver = true;
                            }
                        }
                    }
                }
                player.isMove = true;
            }

            clearFoW();

        }

        private void updateInput()
        {
            KeyboardState newState = Keyboard.GetState();

            if (newState != oldState)
            {

                bool moved = false;
                Vector2 pGP = new Vector2(player.GridPosition.X / 10, player.GridPosition.Y / 10);

                if (newState.IsKeyDown(Keys.W))
                {
                    pGP.Y -= 1;
                    moved = true;
                }
                else if (newState.IsKeyDown(Keys.A))
                {
                    pGP.X -= 1;
                    moved = true;
                }
                else if (newState.IsKeyDown(Keys.S))
                {
                    pGP.Y += 1;
                    moved = true;
                }
                else if (newState.IsKeyDown(Keys.D))
                {
                    pGP.X += 1;
                    moved = true;
                }

                if (newState.IsKeyDown(Keys.F3))
                    fMode = !fMode;

                if (newState.IsKeyDown(Keys.F2)) //DEBUG ONLY, REMOVE FOR RELEASE.
                {

                    Tiles = level1.map();
                    Vector2 spawn = level1.getSpawn();
                    player.jumpRegardless(level1.getSpawn());
                    player.setExit(level1.getExit());
                    player.respawn();
                    FoW = new int[80, 48];
                    score -= 100;
                    if (score < 0) score = 0;
                }

                if (newState.IsKeyDown(Keys.R))
                {
                    if (gameOver)
                    {
                        gameOver = false;

                        Tiles = level1.map();

                        Vector2 spawn = level1.getSpawn();
                        player.jumpRegardless(level1.getSpawn());
                        player.setExit(level1.getExit());
                        player.respawn();
                        FoW = new int[80, 48];
                        score = 0;
                    }
                }

                if (moved)
                {
                    player.jump((int)pGP.X, (int)pGP.Y, Tiles[(int)pGP.X, (int)pGP.Y]);
                    
                    foreach (EnemyBase enemy in enemyList)
                    {
                        if (enemy != null && Tiles[(int)pGP.X, (int)pGP.Y] != 1) enemy.AddAP(100);
                    }
                }

                // Update saved state.
                oldState = newState;
            }
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here
            spriteBatch.Begin();

            if (gameOver)
            {
                spriteBatch.Draw(gameOverScreen, new Rectangle(0, 0, graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight), Color.White);
                spriteBatch.DrawString(GOText, "Score: " + score, new Vector2(32*tileSize, 33*tileSize), Color.Red);
            }
            else
            {
                spriteBatch.Draw(wall, new Rectangle(0, 0, graphics.PreferredBackBufferWidth, graphics.PreferredBackBufferHeight - tileSize * 5), Color.SeaGreen);

                for (int i = 0; i < 80; i++)
                {
                    for (int j = 0; j < 45; j++)
                    {
                        if (FoW[i, j] == 1)
                        {
                            switch (Tiles[i, j])
                            {
                                case -1:
                                    spriteBatch.Draw(wall, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.SlateGray);
                                    break;

                                case 1:
                                case 2:
                                    spriteBatch.Draw(wall, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.SandyBrown);
                                    break;
                                                                    
                                case 3:
                                    spriteBatch.Draw(grate, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.White);
                                    break;

                                case 11:
                                    spriteBatch.Draw(enemy1, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.White);
                                    break;

                                case 12:
                                    spriteBatch.Draw(wall, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.Yellow);
                                    break;

                                case 13:
                                    spriteBatch.Draw(wall, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.Green);
                                    break;
                            }

                            for (int e = 0; e < enemyList.Length; e++)
                            {
                                if (enemyList[e] == null)
                                    continue;
                                if (enemyList[e].GridPosition == new Vector2(i, j))
                                {
                                    spriteBatch.Draw(hpBar, new Rectangle((i + (1 / 40)) * tileSize, (j + (1 / 40)) * tileSize, (int)(tileSize * 38 / 40 * enemyList[e].HP), tileSize * 8 / 40), Color.White);
                                    break;
                                }
                            }
                        }
                        else if (FoW[i, j] == 2 && fMode)
                        {
                            if (Tiles[i, j] != -1)
                            {
                                switch (Tiles[i, j])
                                {
                                    case 1:
                                    case 2:
                                        spriteBatch.Draw(wall, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.SandyBrown);
                                        break;

                                    case 3:
                                        spriteBatch.Draw(grate, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.White);
                                        break;
                                }

                                spriteBatch.Draw(fog, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.White);
                            }
                            else spriteBatch.Draw(wall, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.SlateGray);
                        }
                        else if (fMode) spriteBatch.Draw(wall, new Rectangle(i * tileSize, j * tileSize, tileSize, tileSize), Color.SlateGray);

                    }
                }

                spriteBatch.Draw(wall, new Rectangle((int)player.ScreenPosition.X * tileSize / 10, (int)player.ScreenPosition.Y * tileSize / 10, tileSize, tileSize), Color.White);

                spriteBatch.DrawString(uiText, "Health: " + player.Health, new Vector2(tileSize / 4, 46*tileSize), Color.White);
                spriteBatch.DrawString(uiText, "Score: " + score, new Vector2(tileSize / 4, 48*tileSize), Color.White);

            }


            spriteBatch.End();

            base.Draw(gameTime);
        }

        void getSubTiles(Layouts layout)
        {

            int[,] subTile = new int[26, 24];

            subTile = layout.getLayout();

            for (int i = 0; i < layout.getWidth(); i++)
            {
                for (int j = 0; j < layout.getHeight(); j++)
                {
                    int left = layout.getLeft();
                    int top = layout.getTop();
                    Tiles[i + left, j + top] = subTile[i, j];
                }
            }
        }

        public int getTile(int x, int y)
        {
            return Tiles[x, y];
        }

        private EnemyBase enemyDeath(EnemyBase enemy)
        {
            Vector2 temp = enemy.GridPosition;
            Tiles[(int)temp.X, (int)temp.Y] = 0;
            enemy = null;
            return null;
        }

        void clearFoW()
        {
            Vector2 temp = new Vector2(player.GridPosition.X / 10, player.GridPosition.Y / 10);

            for (int i = 0; i < 80; i++)
            {
                for (int j = 0; j < 48 ; j++)
                {
                    if (FoW[i, j] == 1 && Math.Abs(temp.X - i) + Math.Abs(temp.Y - j) > pDist) FoW[i, j] = 2;
                    else if ((FoW[i, j] == 0 || FoW[i, j] == 2) && Math.Abs(temp.X - i) + Math.Abs(temp.Y - j) <= pDist)
                    {
                        FoW[i, j] = 1;
                    }
                    
                 }
            }

            //int temp = (int)(Math.Abs(gridPosition.X - (target.GridPosition.X / 10)) + Math.Abs(gridPosition.Y - (target.GridPosition.Y / 10)));
            //if(temp < pDist
        }
    }
}
